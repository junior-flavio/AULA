
import java.util.Scanner;
import javax.swing.JOptionPane;


public class BURGUESIA {


    public static void main(String[] args) {

    Scanner sc = new Scanner(System.in);
     
    System.out.println("Digite o nome: ");
    String vNome = sc.nextLine();
    
    
    System.out.println("Digite a idade: ");
    int vidade = sc.nextInt();
    
    System.out.println("Digite a salario: ");
    int vsalario = sc.nextInt();
    
    System.out.println("Nome: " +vNome
                        +"Idade: " +vidade
                         +"Salario: "+vsalario);
  
    
   /*
   String nome;
    JOptionPane.showInputDialog(null, "Digite o nome: ");
    
    
    
    
    
    JOptionPane.showMessageDialog(null,"O nome é:" +nome);
    */
    }} 